import React from 'react';
import './works.css';
import Portfolio1 from '../../assets/portfolio-1.jpg'
import Portfolio2 from '../../assets/portfolio-2.avif'
import Portfolio3 from '../../assets/portfolio-3.jpg'
import Portfolio4 from '../../assets/portfolio-4.avif'
import Portfolio5 from '../../assets/portfolio-5.jpg'
import Portfolio6 from '../../assets/portfolio-6.png'


const Works = () => {
  return (
    <section id='works'>

      <h2 className='workstitle'>My Portfolio</h2>
      <br></br>

      <span className='worksDesc'>I Take pride in paying attention to the smalest details</span>

      <div className='worksImgs'>
        <img src={Portfolio1} alt='' className='worksImg' />
        <img src={Portfolio2} alt='' className='worksImg' />
        <img src={Portfolio3} alt='' className='worksImg' />
        <img src={Portfolio4} alt='' className='worksImg' />
        <img src={Portfolio5} alt='' className='worksImg' />
        <img src={Portfolio6} alt='' className='worksImg' />


      </div>

      <button className='workBtn'>See More</button>
    </section>
  )
}

export default Works;
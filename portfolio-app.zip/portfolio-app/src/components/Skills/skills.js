import React from 'react';
import './skills.css';
import UIDesign from '../../assets/ui-design.png';
import WebDesign from '../../assets/website-design.png';
import AppDesign from '../../assets/app-design.png';


const skills = ()=> {
    return (
        <section id='skills'>
            <span className='skillTitle'>What I do</span>
            <br></br>
            <span className='skillDesc'>I am a skilled and passionate web desinger with experience in desinging Websites</span>

            <div className='skillBars'>
                <div className='skillBar'>
                    <img src={UIDesign} alt='UIDesign' className='skillBarImg' />
                    <div className='skillBarText'>
                        <h2>Full Stack Developer</h2>
                        <p>I am pleased to announce that I have successfully compledted the Full Stack Deeveloper Certificate program from AttainU in 2022.</p>

                    </div>
                </div>

                <div className='skillBar'>
                    <img src={WebDesign} alt='UIDesign' className='skillBarImg' />
                    <div className='skillBarText'>
                        <h2>Technical Consultant</h2>
                        <p>I have worked as an Technical Consultant at Novulis Global Solution Company from 2022 to 2023.</p>

                    </div>
                </div>

             
                     <div className='skillBar'>
                    <img src={AppDesign} alt='UIDesign' className='skillBarImg' />
                    <div className='skillBarText'>
                        <h2>UI/UX Design</h2>
                        <p>I Possess a strong understanding of user-centered design principles,ensuring that digital products are both intuitive and aeesthetically pleasing.</p>

                    </div>
                </div>

                </div>

        </section>
    )
}

export default skills;

import React from 'react';
import './navbar.css';
import { Link } from 'react-scroll';
// import contacting from '../../assets/bg.jpg'

const navbar = () => {
    return (
        <nav className='navbar'>
            <img src='' alt='' />
            <div className='desktopMenu'>
           
                <Link activeClass='active' to='intro' spy={true} offset={-100} duration={500} className='desktopMenuListItem'>Home</Link>
                <Link activeClass='active' to='skills' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>About</Link>
                <Link activeClass='active' to='works' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>Portfolio</Link>
                <Link activeClass='active' to='clients' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>Clients</Link>

            </div>
            <button className='desktopMenuBtn' onClick={() =>{
                document.getElementById('contact').scrollIntoView({behavior: 'smooth'});
            }}>

                <img src='' alt='' className='desktopMenuImg' />Contact Me</button>

                {/* <img src={menu} alt='Menu' className='mobMenu' />
            <div className='navMenu'>
                <Link activeClass='active' to='intro' spy={true} offset={-100} duration={500} className='desktopMenuListItem'>Home</Link>
                <Link activeClass='active' to='skills' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>About</Link>
                <Link activeClass='active' to='works' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>Portfolio</Link>
                <Link activeClass='active' to='clients' spy={true} offset={-50} duration={500} className='desktopMenuListItem'>Clients</Link>

            </div> */}

        </nav>
    )
}
export default navbar;
